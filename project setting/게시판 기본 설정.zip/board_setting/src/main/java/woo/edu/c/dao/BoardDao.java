package woo.edu.c.dao;

import java.util.List;

import woo.edu.c.vo.testVo;

public interface BoardDao {

	List<testVo> test();

}
