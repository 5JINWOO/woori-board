package woo.edu.c.service;

import java.util.List;

import woo.edu.c.vo.testVo;

public interface BoardService {

	List<testVo> test();


}
